public class Conta {
  //Atributos
  private String accountNumber;
  private double balance;
  private String clientName;

  //Construtor
  public Conta (String accountNumber, String clientName){
    this.accountNumber = accountNumber;
    this.balance = 0;
    this.clientName = clientName;
  }
  public void deposit( double value){
    balance += value;
  }
  public void withdraw (double value){
    if (balance >= value){
      balance -= value;
    }
  }

  //Getters
  public double getBalance(){
    return this.balance;
  }

  public String getAccountNumber(){
    return this.accountNumber;
  }
}
