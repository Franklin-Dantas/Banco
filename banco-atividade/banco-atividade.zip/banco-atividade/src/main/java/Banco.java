import java.util.ArrayList;

public class Banco {
  private ArrayList<Conta> accounts;

  public Banco() {
    this.accounts = new ArrayList();
  }

  private boolean contaExistente(String accountNumber){
    for(Conta objetoConta: accounts){
      if (objetoConta.getAccountNumber() == accountNumber){
        return true;
      }
    }
    return false;
  }

  public void criarConta(String accountNumber, String userName){
    if (!contaExistente(accountNumber)){
      accounts.add(new Conta(accountNumber, userName));
    }
  }

  public static void main(String[] args) {
    Banco bank = new Banco();
    bank.criarConta("1234","Geraldao");

    Conta geraldao = new Conta("1234","Geraldao");
    System.out.println(geraldao.getBalance());
    geraldao.deposit(10000);
    System.out.println(geraldao.getBalance());
    geraldao.withdraw(500);
    System.out.println(geraldao.getBalance());
  }

}
